Legacy OpenCore By chris1111

- Works on an Internal or External disk
- Works on HFS+J or APFS file system
- The program can be used with SIP enabled

* Credit:
[chris1111 Legacy-OpenCore-Package](https://github.com/chris1111/Legacy-OpenCore-Package)
[Acidanthera](https://github.com/acidanthera/OpenCorePkg) 
[partutil JrCs](https://github.com/chris1111/partutil) 
[MountESP Clover team](https://github.com/CloverHackyColor/CloverBootloader/tree/master/CloverPackage/package/Scripts.templates/EFIFolder)